package com.trsub.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val AppBg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B25)
private val Accent = Color(0xFF7C5CFF)
private val TextMain = Color(0xFFF4F5FA)
private val TextMuted = Color(0xFF9BA3B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TRSubApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TRSubApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var subtitlesEnabled by remember { mutableStateOf(false) }
    var isTranscribing by remember { mutableStateOf(false) }
    var sourceLanguage by remember { mutableStateOf(SourceLanguage.JAPANESE) }
    var expanded by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("اختر فيديو للبدء") }
    var cues by remember { mutableStateOf<List<SubtitleCue>>(emptyList()) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var subtitleText by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            cues = emptyList()
            subtitleText = ""
            subtitlesEnabled = false
            status = "تم اختيار الفيديو. اضغط «إنشاء الترجمة العربية»."
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }
    LaunchedEffect(videoUri) {
        videoUri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
            player.playWhenReady = true
        }
    }
    LaunchedEffect(player, subtitlesEnabled, cues) {
        while (true) {
            currentPosition = player.currentPosition.coerceAtLeast(0L)
            subtitleText = if (subtitlesEnabled) {
                cues.firstOrNull { currentPosition >= it.startMs && currentPosition <= it.endMs }?.arabic.orEmpty()
            } else ""
            delay(150)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = AppBg, surface = Panel,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Scaffold(containerColor = AppBg) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(46.dp).background(Accent, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("字幕", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("TR.SUB", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("مشغل فيديو وترجمة عربية", color = TextMuted, fontSize = 13.sp)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (videoUri != null) {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx -> PlayerView(ctx).apply {
                                    this.player = player
                                    useController = true
                                } },
                                update = { it.player = player }
                            )
                            if (subtitleText.isNotBlank()) {
                                Text(
                                    subtitleText,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.BottomCenter)
                                        .fillMaxWidth().padding(bottom = 62.dp, start = 12.dp, end = 12.dp)
                                        .background(Color(0xDD000000), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 12.dp, vertical = 9.dp)
                                )
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Subtitles, contentDescription = null, tint = Accent, modifier = Modifier.size(58.dp))
                                Spacer(Modifier.height(12.dp))
                                Text("مشاهدة بترجمة عربية", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                Text("اختر فيديو من جهازك", color = TextMuted, fontSize = 14.sp)
                            }
                        }
                    }
                }

                Button(
                    onClick = { picker.launch(arrayOf("video/mp4", "video/*")) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("اختيار فيديو", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }

                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = sourceLanguage.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("لغة الحوار في الفيديو") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        SourceLanguage.entries.forEach { language ->
                            DropdownMenuItem(
                                text = { Text(language.label) },
                                onClick = { sourceLanguage = language; expanded = false }
                            )
                        }
                    }
                }

                Button(
                    enabled = videoUri != null && !isTranscribing,
                    onClick = {
                        val uri = videoUri ?: return@Button
                        isTranscribing = true
                        subtitlesEnabled = false
                        cues = emptyList()
                        status = "جارٍ تجهيز نموذج التعرف على الكلام… قد يتطلب تنزيله أول مرة."
                        scope.launch {
                            try {
                                val result = withContext(Dispatchers.IO) {
                                    SubtitlePipeline(context).createArabicSubtitles(uri, sourceLanguage) { message ->
                                        scope.launch { status = message }
                                    }
                                }
                                cues = result
                                subtitlesEnabled = true
                                status = if (result.isEmpty()) "لم يُعثر على كلام واضح في هذا الفيديو." else "اكتملت الترجمة: ${result.size} مقطعًا."
                            } catch (e: Exception) {
                                status = "تعذر إنشاء الترجمة: ${e.message ?: "خطأ غير معروف"}"
                            } finally {
                                isTranscribing = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isTranscribing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                        Spacer(Modifier.width(10.dp))
                        Text("جارٍ إنشاء الترجمة…")
                    } else {
                        Icon(Icons.Default.Translate, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("إنشاء الترجمة العربية", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    enabled = cues.isNotEmpty(),
                    onClick = { subtitlesEnabled = !subtitlesEnabled },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.Subtitles, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (subtitlesEnabled) "إيقاف الترجمة العربية" else "تشغيل الترجمة العربية")
                }

                Text(status, color = TextMuted, fontSize = 12.sp)
                Text("التعرّف والترجمة يعملان على الجهاز بعد تنزيل النماذج أول مرة.", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}

internal enum class SourceLanguage(val label: String, val voskUrl: String, val mlKitCode: String, val folder: String) {
    JAPANESE(
        "اليابانية",
        "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
        com.google.mlkit.nl.translate.TranslateLanguage.JAPANESE,
        "vosk-ja"
    ),
    ENGLISH(
        "الإنجليزية",
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
        com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH,
        "vosk-en"
    )
}

internal data class SubtitleCue(val startMs: Long, val endMs: Long, val arabic: String)
