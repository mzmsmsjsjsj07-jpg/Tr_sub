package com.trsub.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.gson.JsonParser
import kotlinx.coroutines.tasks.await
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.roundToInt

internal class SubtitlePipeline(private val context: Context) {

    suspend fun createArabicSubtitles(
        uri: Uri,
        language: SourceLanguage,
        onStatus: (String) -> Unit
    ): List<SubtitleCue> {
        val modelDir = ensureModel(language, onStatus)
        onStatus("تم تجهيز نموذج اللغة. جارٍ تحليل صوت الفيديو…")
        val model = Model(modelDir.absolutePath)
        try {
            val recognizer = Recognizer(model, 16_000.0f)
            val rawCues = try {
                decodeAndRecognize(uri, recognizer, onStatus)
            } finally {
                recognizer.close()
            }
            if (rawCues.isEmpty()) return emptyList()

            onStatus("تم التعرف على ${rawCues.size} مقطعًا. جارٍ تنزيل/تجهيز الترجمة العربية…")
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(language.mlKitCode)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded().await()
                val output = mutableListOf<SubtitleCue>()
                rawCues.forEachIndexed { index, cue ->
                    onStatus("ترجمة المقطع ${index + 1} من ${rawCues.size}…")
                    val translated = translator.translate(cue.text).await().trim()
                    if (translated.isNotBlank()) {
                        output += SubtitleCue(cue.startMs, max(cue.endMs, cue.startMs + 1200), translated)
                    }
                }
                return output
            } finally {
                translator.close()
            }
        } finally {
            model.close()
        }
    }

    private suspend fun ensureModel(language: SourceLanguage, onStatus: (String) -> Unit): File {
        val parent = File(context.filesDir, "speech-models").apply { mkdirs() }
        val target = File(parent, language.folder)
        if (File(target, "am").exists() || File(target, "conf").exists()) return target

        val archive = File(parent, "${language.folder}.zip")
        onStatus("تنزيل نموذج التعرف على ${language.label} (مرة واحدة)…")
        val connection = (URL(language.voskUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                error("تعذر تنزيل نموذج اللغة (HTTP ${connection.responseCode}).")
            }
            connection.inputStream.use { input ->
                FileOutputStream(archive).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    var count: Int
                    while (input.read(buffer).also { count = it } >= 0) {
                        output.write(buffer, 0, count)
                        total += count
                        if (total > 0) onStatus("تنزيل نموذج اللغة… ${(total / (1024 * 1024))} ميجابايت")
                    }
                }
            }
        } finally {
            connection.disconnect()
        }

        onStatus("فك ضغط نموذج التعرف على الكلام…")
        val staging = File(parent, "${language.folder}-extract").apply {
            deleteRecursively()
            mkdirs()
        }
        ZipInputStream(BufferedInputStream(archive.inputStream())).use { zip ->
            var entry = zip.nextEntry
            val buffer = ByteArray(32 * 1024)
            while (entry != null) {
                val out = File(staging, entry.name).canonicalFile
                require(out.path.startsWith(staging.canonicalPath + File.separator)) { "ملف النموذج غير صالح" }
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { output ->
                        var n: Int
                        while (zip.read(buffer).also { n = it } > 0) output.write(buffer, 0, n)
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        val modelRoot = staging.walkTopDown().firstOrNull { it.isDirectory && File(it, "am").exists() }
            ?: staging.walkTopDown().firstOrNull { it.isDirectory && File(it, "conf").exists() }
            ?: error("ملفات النموذج التي تم تنزيلها غير مكتملة.")
        target.deleteRecursively()
        if (modelRoot == staging) {
            if (!staging.renameTo(target)) staging.copyRecursively(target, overwrite = true)
        } else {
            modelRoot.copyRecursively(target, overwrite = true)
        }
        archive.delete()
        staging.deleteRecursively()
        if (!File(target, "am").exists() && !File(target, "conf").exists()) {
            target.deleteRecursively()
            error("فشل تثبيت نموذج التعرف على الكلام.")
        }
        return target
    }

    private data class RawCue(val startMs: Long, val endMs: Long, val text: String)

    private fun decodeAndRecognize(
        uri: Uri,
        recognizer: Recognizer,
        onStatus: (String) -> Unit
    ): List<RawCue> {
        val extractor = MediaExtractor()
        val cues = mutableListOf<RawCue>()
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrack = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    audioTrack = i
                    inputFormat = f
                    break
                }
            }
            if (audioTrack < 0 || inputFormat == null) error("الفيديو لا يحتوي على مسار صوتي.")
            extractor.selectTrack(audioTrack)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("صيغة الصوت غير معروفة.")
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()
            try {
                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var outputRate = inputFormat.getIntegerOrDefault(MediaFormat.KEY_SAMPLE_RATE, 44100)
                var outputChannels = inputFormat.getIntegerOrDefault(MediaFormat.KEY_CHANNEL_COUNT, 1)
                var bytesFed = 0L
                var lastStatusAt = 0L

                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = decoder.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val inputBuffer = decoder.getInputBuffer(inputIndex)!!
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = decoder.outputFormat
                            outputRate = f.getIntegerOrDefault(MediaFormat.KEY_SAMPLE_RATE, outputRate)
                            outputChannels = f.getIntegerOrDefault(MediaFormat.KEY_CHANNEL_COUNT, outputChannels)
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        else -> if (outputIndex >= 0) {
                            val outBuffer = decoder.getOutputBuffer(outputIndex)
                            if (outBuffer != null && info.size > 0) {
                                outBuffer.position(info.offset)
                                outBuffer.limit(info.offset + info.size)
                                val pcm = ByteArray(info.size)
                                outBuffer.get(pcm)
                                val mono16k = toMono16k(pcm, outputRate, outputChannels)
                                if (mono16k.isNotEmpty()) {
                                    if (recognizer.acceptWaveForm(mono16k, mono16k.size)) {
                                        addResult(cues, recognizer.result)
                                    }
                                    bytesFed += mono16k.size
                                }
                                val seconds = bytesFed / 32000L
                                if (seconds >= lastStatusAt + 5) {
                                    lastStatusAt = seconds
                                    onStatus("تحليل الصوت… ${seconds} ثانية")
                                }
                            }
                            decoder.releaseOutputBuffer(outputIndex, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        }
                    }
                }
                addResult(cues, recognizer.finalResult)
            } finally {
                decoder.stop()
                decoder.release()
            }
        } finally {
            extractor.release()
        }
        return cues.filter { it.text.isNotBlank() && it.endMs > it.startMs }
            .sortedBy { it.startMs }
    }

    private fun addResult(cues: MutableList<RawCue>, json: String) {
        try {
            val root = JsonParser.parseString(json).asJsonObject
            val text = root.get("text")?.asString?.trim().orEmpty()
            if (text.isBlank()) return
            val words = root.getAsJsonArray("result")
            val start = if (words != null && words.size() > 0) words.first().asJsonObject.get("start").asDouble else 0.0
            val end = if (words != null && words.size() > 0) words.last().asJsonObject.get("end").asDouble else start + 2.0
            cues += RawCue((start * 1000).toLong(), (end * 1000).toLong(), text)
        } catch (_: Exception) {
            // A malformed partial result is ignored; final recognition still completes.
        }
    }

    private fun toMono16k(pcm: ByteArray, sampleRate: Int, channels: Int): ByteArray {
        if (pcm.size < 2 || sampleRate <= 0 || channels <= 0) return ByteArray(0)
        val buffer = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        val sampleCount = pcm.size / 2
        val frameCount = sampleCount / channels
        if (frameCount <= 0) return ByteArray(0)
        val mono = ShortArray(frameCount)
        for (frame in 0 until frameCount) {
            var sum = 0
            for (channel in 0 until channels) sum += buffer.getShort((frame * channels + channel) * 2).toInt()
            mono[frame] = (sum / channels).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        val outCount = max(1, (frameCount.toDouble() * 16000.0 / sampleRate).roundToInt())
        val out = ByteBuffer.allocate(outCount * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until outCount) {
            val sourcePos = i.toDouble() * sampleRate / 16000.0
            val left = sourcePos.toInt().coerceIn(0, frameCount - 1)
            val right = (left + 1).coerceAtMost(frameCount - 1)
            val fraction = sourcePos - left
            val value = (mono[left] * (1.0 - fraction) + mono[right] * fraction).roundToInt()
            out.putShort(value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort())
        }
        return out.array()
    }

    private fun MediaFormat.getIntegerOrDefault(key: String, default: Int): Int =
        if (containsKey(key)) getInteger(key) else default
}
